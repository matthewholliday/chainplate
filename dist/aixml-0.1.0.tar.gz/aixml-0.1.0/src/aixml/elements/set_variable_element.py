from ..message import Message

class SetVariableElement:
    def __init__(self, var_name, content):
        self.var_name = "unnamed" if var_name is None else var_name
        self.content = content

    def enter(self , message: Message) -> Message:
        message.log(f"SetVariableElement: var {self.var_name} = {self.content}")
        message.set_var(self.var_name, self.content)
        return message

    def exit(self, message: Message) -> Message:
        return message
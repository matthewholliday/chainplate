from ..message import Message
from ..helpers.template_helper import TemplateHelper

class SendPromptElement:
    def __init__(self, name, var_name, content):
        self.name = "unnamed" if name is None else name
        self.var_name = "unnamed" if var_name is None else var_name
        self.content = content
        self.transformed_content = None

    def enter(self , message: Message) -> Message:
        message.log(f" >> SendPromptElement >> transforming_content: \n\n {self.content}")
        message = self.try_transform_content(message)
        message.log(f"SendPromptElement >> setting variable {self.var_name} = {self.content}")
        message = self.try_set_variable(message)
        return message

    def exit(self, message: Message) -> Message:
        return message
    
    def try_transform_content(self, message: Message) -> Message:
        if self.transformed_content is None and self.content:
            if message.has_template_bindings(self.content):
                message.log(f"Transforming content for prompt '{self.name}' with variables: {message.variables}")
                self.transformed_content = TemplateHelper.render_template(self.content, message.variables)
            else:
                message.log(f"ERROR: No template bindings found in content for prompt '{self.name}'. Using original content.")
                self.transformed_content = self.content
        return message
    
    def try_set_variable(self, message: Message) -> Message:
        if self.var_name and self.content:
            message.set_var(self.var_name, self.content)
            message.log(f" >> Set variable: {self.var_name} to {self.transformed_content}")
        return message
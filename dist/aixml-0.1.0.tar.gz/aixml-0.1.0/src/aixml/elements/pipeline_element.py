from ..message import Message

class PipelineElement:
    def __init__(self, name):
        self.name = name

    def enter(self, message:Message) -> Message:
        return message

    def exit(self, message:Message) -> Message:
        return message
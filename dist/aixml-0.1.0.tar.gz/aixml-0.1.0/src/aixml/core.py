from .tree import TreeNode
from .ainode import AiNode
from .message import Message
import json

class AIXMLCore:
    def __init__(self):
        pass

    @staticmethod
    def parse(xml_string: str) -> TreeNode:
        json_str = TreeNode.get_xml_as_json_string(xml_string)
        return json_str
    
    @staticmethod
    def execute(xml_string: str):
        json_str = TreeNode.get_xml_as_json_string(xml_string)
        data = json.loads(json_str)
        node = AiNode.from_dict(data)

        msg = Message()

        node.execute(msg)
        print("")
        print("============MESSAGE-LOG============")
        print("")
        msg.print_logs()
        print("")
        print("===================================")
        print("")
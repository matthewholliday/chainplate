from .helpers.template_helper import TemplateHelper

class Message:
    def __init__(self):
        self.logs = []
        self.vars = {}

    def log(self, message: str):
        self.logs.append(message)

    def get_logs(self):
        return self.logs
    
    def print_logs(self):
        for log in self.logs:
            print(log)

    def set_var(self, key: str, value):
        self.vars[key] = value

    def has_var(self, key: str) -> bool:
        return key in self.vars
    
    def get_var(self, key: str):
        return self.vars.get(key, None)
    
    def has_all_vars(self, keys: list) -> bool:
        return all(key in self.vars for key in keys)
    
    def has_template_bindings(self, template_str: str) -> bool:
        required_vars = TemplateHelper.get_template_vars(template_str)
        return self.has_all_vars(required_vars)


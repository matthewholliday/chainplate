import json
from dataclasses import dataclass, field
from typing import List, Any, Dict
from .elements.pipeline_element import PipelineElement
from .elements.send_prompt_element import SendPromptElement
from .message import Message

@dataclass
class AiNode:
    tag: str
    contents: str
    children: List["AiNode"] = field(default_factory=list)
    attributes: Dict[str, Any] = field(default_factory=dict)
    element: Any = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "AiNode":
        """Recursively build a AiNode tree from a dict."""

        tag = data["tag"]
        text = data.get("text", "")
        contents = data["contents"]
        attributes = data.get("attributes", {})
        children = [cls.from_dict(child) for child in data.get("children", [])]
        element = cls.get_element_by_tag(tag,attributes,text)


        return cls(
            tag=tag,
            contents=contents,
            attributes=attributes,
            children=children,
            element = element
        )

    def __str__(self, level=0) -> str:
        """Pretty-print the tree for inspection."""
        indent = "  " * level
        result = f"{indent}{self.tag}: {self.contents!r}\n"
        for child in self.children:
            result += child.__str__(level + 1)
        return result
    
    @staticmethod
    def get_element_by_tag(tag: str, attributes, text) -> List["AiNode"]:
        if tag == "pipeline":
            return PipelineElement(attributes.get("name", "Unnamed Pipeline"))
        elif tag == "send-prompt":
            return SendPromptElement(
                name=attributes.get("name", "Unnamed Prompt"),
                var_name=attributes.get("var_name", "Unnamed Variable"),
                content=attributes.get("content", "")
            )
        elif tag == "set-variable":
            from .elements.set_variable_element import SetVariableElement
            return SetVariableElement(
                var_name=attributes.get("var_name", "Unnamed Variable"),
                content=text
            )
        else:
            return None # Placeholder for other elements
    
    @staticmethod
    def pretty_print(is_enter: bool, tag: str, depth: int):
        spacing = "  " * depth
        prefix = ">> " if is_enter else "<< "
        # print(spacing + prefix + f"{tag}")

    def enter(self,message,depth) -> Message:
        AiNode.pretty_print(True,self.tag,depth)
        if(self.element):
            message = self.element.enter(message)
        return message

    def exit(self,message,depth) -> Message:
        AiNode.pretty_print(False,self.tag,depth - 1)
        if(self.element):
            message = self.element.exit(message)
        return message

    def execute(self,message,depth=0) -> Message:
        """Execute the node's action. Placeholder for actual logic."""
        message = self.enter(message,depth)
        depth += 1
        for child in self.children:
            message = child.execute(message,depth)
       
        message = self.exit(message,depth)
        return message

    